const wrap = document.getElementById("wrap");
wrap.classList.remove("h2");
wrap.offsetWidth;
wrap.classList.add("h2");

const wrap = document.getElementById("wrap");
wrap.classList.remove(".image");
wrap.offsetWidth;
wrap.classList.add("image");